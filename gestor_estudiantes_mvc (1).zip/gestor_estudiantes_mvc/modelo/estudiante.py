"""
modelo/estudiante.py

Funciones de persistencia (SQLite) para el Gestor de Estudiantes.
Responsabilidad única: todo lo relacionado con la base de datos.
"""

import csv
import sqlite3
from pathlib import Path
from typing import List, Tuple, Optional

BASE_DIR = Path(__file__).resolve().parents[2]  # project root
DB_PATH = BASE_DIR / "estudiantes.db"
CSV_PATH = BASE_DIR / "estudiantes.csv"

def conectar(nombre_bd: str = None):
    """Devuelve conexión y cursor hacia la base de datos SQLite."""
    nombre = nombre_bd or str(DB_PATH)
    conn = sqlite3.connect(nombre)
    conn.execute("PRAGMA foreign_keys = ON;")
    cur = conn.cursor()
    return conn, cur

def crear_base(nombre_bd: str = None) -> None:
    """Crea la base de datos y la tabla estudiantes si no existen."""
    conn, cur = conectar(nombre_bd)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS estudiantes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT NOT NULL,
        correo TEXT NOT NULL UNIQUE,
        nota REAL
    )
    """)
    conn.commit()
    conn.close()

def generar_csv(nombre_archivo: str = None) -> None:
    """Genera un CSV de ejemplo con encabezados y registros de prueba."""
    nombre = Path(nombre_archivo) if nombre_archivo else CSV_PATH
    datos = [
        ["nombre", "correo", "nota"],
        ["Ana", "ana@mail.com", "4.5"],
        ["Luis", "luis@mail.com", "3.8"],
        ["Sara", "sara@mail.com", "4.2"],
    ]
    with open(nombre, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerows(datos)
    print(f"[OK] Archivo CSV generado en: {nombre}")

def importar_datos(csv_file: str = None, nombre_bd: str = None) -> None:
    """Importa registros desde un CSV hacia la base de datos SQLite."""
    csv_path = Path(csv_file) if csv_file else CSV_PATH
    if not csv_path.exists():
        raise FileNotFoundError(f"No se encontró el CSV: {csv_path}")
    crear_base(nombre_bd)
    conn, cur = conectar(nombre_bd)
    with open(csv_path, newline="", encoding="utf-8") as f:
        lector = csv.DictReader(f)
        for fila in lector:
            try:
                cur.execute(
                    "INSERT INTO estudiantes (nombre, correo, nota) VALUES (?, ?, ?)",
                    (fila["nombre"].strip(), fila["correo"].strip(), float(fila["nota"]))
                )
            except sqlite3.IntegrityError:
                # registro duplicado por correo
                print(f"[ADVERTENCIA] Registro duplicado (correo): {fila.get('correo')}")
    conn.commit()
    conn.close()
    print("[OK] Importación finalizada.")

def agregar_estudiante(nombre: str, correo: str, nota: float, nombre_bd: str = None) -> Tuple[bool, str]:
    """Inserta un nuevo estudiante. Devuelve (exito, mensaje)."""
    conn, cur = conectar(nombre_bd)
    try:
        cur.execute(
            "INSERT INTO estudiantes (nombre, correo, nota) VALUES (?, ?, ?)",
            (nombre.strip(), correo.strip(), float(nota))
        )
        conn.commit()
        return True, "Estudiante agregado correctamente."
    except sqlite3.IntegrityError as e:
        return False, f"Error: {e}"
    finally:
        conn.close()

def listar_estudiantes(nombre_bd: str = None) -> List[Tuple[int, str, str, float]]:
    """Devuelve todos los estudiantes como lista de tuplas (id, nombre, correo, nota)."""
    conn, cur = conectar(nombre_bd)
    cur.execute("SELECT id, nombre, correo, nota FROM estudiantes")
    filas = cur.fetchall()
    conn.close()
    return filas

def actualizar_nota_por_nombre(nombre_est: str, nueva_nota: float, nombre_bd: str = None) -> int:
    """Actualiza la nota de un estudiante por nombre. Devuelve número de filas afectadas."""
    conn, cur = conectar(nombre_bd)
    cur.execute("UPDATE estudiantes SET nota = ? WHERE nombre = ?", (float(nueva_nota), nombre_est.strip()))
    conn.commit()
    afectadas = cur.rowcount
    conn.close()
    return afectadas

def eliminar_por_nota_umbral(umbral: float, nombre_bd: str = None) -> int:
    """Elimina los estudiantes cuya nota sea menor que el umbral. Devuelve filas eliminadas."""
    conn, cur = conectar(nombre_bd)
    cur.execute("DELETE FROM estudiantes WHERE nota < ?", (float(umbral),))
    conn.commit()
    afectadas = cur.rowcount
    conn.close()
    return afectadas

def buscar_por_nombre_parcial(patron: str, nombre_bd: str = None) -> List[Tuple[int, str, str, float]]:
    """Busca estudiantes cuyo nombre contenga el patrón (LIKE)."""
    conn, cur = conectar(nombre_bd)
    like = f"%{patron}%"
    cur.execute("SELECT id, nombre, correo, nota FROM estudiantes WHERE nombre LIKE ? COLLATE NOCASE", (like,))
    filas = cur.fetchall()
    conn.close()
    return filas

def listar_ordenado_desc(nombre_bd: str = None) -> List[Tuple[int, str, str, float]]:
    """Lista estudiantes ordenados por nota descendente."""
    conn, cur = conectar(nombre_bd)
    cur.execute("SELECT id, nombre, correo, nota FROM estudiantes ORDER BY nota DESC")
    filas = cur.fetchall()
    conn.close()
    return filas
