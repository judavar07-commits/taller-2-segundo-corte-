"""
controlador/gestor.py

Lógica de negocio: coordina acciones entre la vista y el modelo.
"""

from typing import Tuple, List
from modelo.estudiante import (
    crear_base, generar_csv, importar_datos, agregar_estudiante,
    listar_estudiantes, actualizar_nota_por_nombre,
    eliminar_por_nota_umbral, buscar_por_nombre_parcial, listar_ordenado_desc
)

def inicializar(proyecto_raiz: str = None) -> None:
    """Inicializa los datos: CSV y DB si es necesario."""
    # generar CSV si no existe, crear DB y importar datos
    generar_csv()
    crear_base()
    importar_datos()

def accion_agregar(nombre: str, correo: str, nota: float) -> Tuple[bool, str]:
    return agregar_estudiante(nombre, correo, nota)

def accion_listar() -> List[Tuple[int, str, str, float]]:
    return listar_estudiantes()

def accion_actualizar_nota(nombre: str, nueva_nota: float) -> Tuple[bool, str]:
    afectadas = actualizar_nota_por_nombre(nombre, nueva_nota)
    if afectadas > 0:
        return True, f"Nota de '{nombre}' actualizada a {nueva_nota}."
    else:
        return False, f"No se encontró estudiante con nombre '{nombre}'."

def accion_eliminar_por_umbral(umbral: float) -> Tuple[bool, str]:
    afectadas = eliminar_por_nota_umbral(umbral)
    if afectadas > 0:
        return True, f"Se eliminaron {afectadas} estudiante(s) con nota < {umbral}."
    else:
        return False, "No se eliminaron registros."

def accion_buscar_parcial(patron: str) -> List[Tuple[int, str, str, float]]:
    return buscar_por_nombre_parcial(patron)

def accion_listar_ordenado() -> List[Tuple[int, str, str, float]]:
    return listar_ordenado_desc()
