Gestor de Estudiantes (MVC) - Consola
=====================================

Estructura:
- modelo/estudiante.py  -> funciones de acceso a datos (SQLite + CSV)
- controlador/gestor.py -> lógica de negocio (coordina modelo y vista)
- vista/main.py         -> interfaz por consola (menú interactivo)

Ejecución:
1. Abra Visual Studio Code.
2. Copie la carpeta `gestor_estudiantes_mvc` a su área de trabajo o abra `/mnt/data/gestor_estudiantes_mvc`.
3. En una terminal Python (recomendado usar un virtualenv) ejecute:
   python vista/main.py

El programa generará `estudiantes.csv` y `estudiantes.db` en la carpeta del proyecto si no existen,
importará los datos y mostrará el menú por consola.

Funcionalidades implementadas:
- Agregar estudiante (INSERT)
- Listar estudiantes (SELECT)
- Actualizar nota por nombre (UPDATE)
- Eliminar registros por umbral (DELETE)
- Buscar por nombre parcial (LIKE)
- Listar ordenado por nota descendente (ORDER BY)

Notas:
- Los cambios en la base (INSERT/UPDATE/DELETE) son persistentes.
- El correo debe ser único (constraint UNIQUE).