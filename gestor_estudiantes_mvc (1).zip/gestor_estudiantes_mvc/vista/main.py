"""
vista/main.py

Interfaz por consola (menú) para interactuar con el Gestor de Estudiantes.
"""

import sys
from pathlib import Path

# Allow running from the project root or from inside vista/
PROJ_ROOT = Path(__file__).resolve().parents[2]
if str(PROJ_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJ_ROOT))

from controlador.gestor import (
    inicializar, accion_agregar, accion_listar, accion_actualizar_nota,
    accion_eliminar_por_umbral, accion_buscar_parcial, accion_listar_ordenado
)

def mostrar_menu():
    print("\nGestor de Estudiantes (MVC) — Menú")
    print("----------------------------------")
    print("1. Agregar estudiante")
    print("2. Listar estudiantes")
    print("3. Actualizar nota (por nombre)")
    print("4. Eliminar registros por umbral de nota")
    print("5. Buscar por nombre (coincidencia parcial)")
    print("6. Listar ordenado por nota (descendente)")
    print("7. Salir")

def pedir_datos_agregar():
    nombre = input("Nombre: ").strip()
    correo = input("Correo: ").strip()
    while True:
        try:
            nota = float(input("Nota (ej: 4.5): ").strip())
            break
        except ValueError:
            print("Nota inválida. Intente de nuevo.")
    return nombre, correo, nota

def imprimir_lista(filas):
    if not filas:
        print("[INFO] No hay registros.")
        return
    print("\nID | Nombre        | Correo               | Nota")
    print("------------------------------------------------")
    for _id, nombre, correo, nota in filas:
        print(f"{_id:2d} | {nombre:12s} | {correo:20s} | {nota:.2f}")

def main():
    print("Inicializando gestor...")
    try:
        inicializar()
    except Exception as e:
        print(f"[ERROR] Inicialización: {e}")
    while True:
        mostrar_menu()
        opcion = input("Seleccione opción (1-7): ").strip()
        if opcion == "1":
            nombre, correo, nota = pedir_datos_agregar()
            ok, msg = accion_agregar(nombre, correo, nota)
            print(msg)
        elif opcion == "2":
            filas = accion_listar()
            imprimir_lista(filas)
        elif opcion == "3":
            nombre = input("Nombre del estudiante a actualizar: ").strip()
            try:
                nueva = float(input("Nueva nota: ").strip())
            except ValueError:
                print("Nota inválida.")
                continue
            ok, msg = accion_actualizar_nota(nombre, nueva)
            print(msg)
        elif opcion == "4":
            try:
                umbral = float(input("Eliminar registros con nota < (ej 3.0): ").strip())
            except ValueError:
                print("Umbral inválido.")
                continue
            ok, msg = accion_eliminar_por_umbral(umbral)
            print(msg)
        elif opcion == "5":
            patron = input("Cadena a buscar en el nombre: ").strip()
            filas = accion_buscar_parcial(patron)
            imprimir_lista(filas)
        elif opcion == "6":
            filas = accion_listar_ordenado()
            imprimir_lista(filas)
        elif opcion == "7":
            print("Saliendo. ¡Hasta luego!")
            break
        else:
            print("Opción inválida. Intente de nuevo.")

if __name__ == "__main__":
    main()
